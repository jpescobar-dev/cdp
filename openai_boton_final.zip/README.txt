ZIP FINAL BOTON ANALIZAR

Incluye:
- Servicio OpenAI básico
- Controller de prueba
- Ruta
- Botón blade

Primero valida conexión, luego se mejora lógica.
