<?php

namespace App\Services\Contractual;

use App\Models\RevisionContractual;
use Illuminate\Support\Facades\Http;

class OpenAIRevisionContractualService
{
    public function analizar(RevisionContractual $revision): array
    {
        $revision->load(['documentos']);

        $response = Http::withToken(config('services.openai.key'))
            ->baseUrl(config('services.openai.base_url'))
            ->post('/responses', [
                'model' => config('services.openai.model'),
                'input' => "Analiza esta revisión contractual y devuelve JSON con resumen, hallazgos y checklist"
            ]);

        if ($response->failed()) {
            throw new \RuntimeException($response->body());
        }

        return $response->json();
    }
}
