<?php

namespace App\Http\Controllers\Contractual;

use App\Http\Controllers\Controller;
use App\Models\RevisionContractual;
use App\Services\Contractual\OpenAIRevisionContractualService;

class AnalisisRevisionContractualController extends Controller
{
    public function store(RevisionContractual $revision, OpenAIRevisionContractualService $service)
    {
        $data = $service->analizar($revision);

        return back()->with('success', 'Análisis ejecutado (debug)');
    }
}
