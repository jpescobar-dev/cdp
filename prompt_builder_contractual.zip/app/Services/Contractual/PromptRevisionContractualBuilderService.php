<?php

namespace App\Services\Contractual;

use App\Models\RevisionContractual;
use Illuminate\Support\Facades\Storage;

class PromptRevisionContractualBuilderService
{
    protected string $basePath = 'prompts/contractual/';

    public function build(RevisionContractual $revision): string
    {
        $partes = [
            $this->read('01_contexto.md'),
            $this->read('02_objetivo.md'),
            $this->read('03_datos.md'),
            $this->read('04_restricciones.md'),
            $this->read('05_estilo.md'),
            $this->read('06_formato_salida.md'),
        ];

        $contenidoBase = implode("\n\n", $partes);
        $datosRevision = $this->buildDatosRevision($revision);

        return $contenidoBase . "\n\n" . $datosRevision;
    }

    protected function read(string $file): string
    {
        return Storage::disk('local')->get($this->basePath . $file);
    }

    protected function buildDatosRevision(RevisionContractual $revision): string
    {
        $revision->load('documentos');

        $documentos = $revision->documentos->map(function ($doc) {
            $tipo = $doc->tipo_documento ?: 'SIN TIPO';
            $ruta = $doc->ruta ?: 'SIN RUTA';
            return "- {$doc->nombre_original} ({$tipo}) | ruta: {$ruta}";
        })->implode("\n");

        if (blank($documentos)) {
            $documentos = '- No existen documentos cargados en la revisión.';
        }

        $descripcion = $revision->descripcion ?: 'Sin descripción';

        return <<<TXT
# DOCUMENTACIÓN A ANALIZAR

## Identificación de la revisión
- ID revisión: {$revision->id}
- Título: {$revision->titulo}
- Descripción: {$descripcion}

## Documentos disponibles
{$documentos}

## Instrucción final
Realiza la revisión contractual preliminar aplicando estrictamente las reglas anteriores.
Trabaja solo con la información disponible.
Si faltan antecedentes, indícalo expresamente.
TXT;
    }
}
