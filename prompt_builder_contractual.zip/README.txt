Prompt Builder Contractual

Incluye:
- Servicio PromptRevisionContractualBuilderService
- Snippet para integrarlo en OpenAIRevisionContractualService
- Estructura esperada de storage para los .md

Objetivo:
- Leer las 6 capas desde storage/app/prompts/contractual/
- Construir un prompt único
- Inyectar datos reales de la revisión y sus documentos

Pasos:
1. Copiar el servicio a app/Services/Contractual/
2. Guardar los 6 .md en storage/app/prompts/contractual/
3. Integrar el snippet en OpenAIRevisionContractualService
4. Ejecutar:
   php artisan optimize:clear
