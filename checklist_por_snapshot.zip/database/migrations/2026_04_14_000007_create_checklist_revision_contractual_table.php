<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('checklist_revision_contractual', function (Blueprint $table) {
            $table->id();

            $table->foreignId('snapshot_revision_contractual_id')
                ->constrained('snapshots_revision_contractual')
                ->cascadeOnDelete();

            $table->string('item', 255);
            $table->string('estado_item', 50);
            $table->longText('observacion')->nullable();
            $table->longText('referencia_documental')->nullable();
            $table->unsignedInteger('orden')->default(0);
            $table->foreignId('user_id')->constrained('users');
            $table->timestamps();

            $table->index('snapshot_revision_contractual_id', 'idx_checklist_snapshot');
            $table->index('estado_item', 'idx_checklist_estado');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('checklist_revision_contractual');
    }
};
