Paquete Checklist por Snapshot

Incluye:
- Migración de checklist_revision_contractual
- Modelo ChecklistRevisionContractual
- Controller ChecklistRevisionContractualController
- Vistas:
  - contractual/checklist/index.blade.php
  - contractual/checklist/create.blade.php
- Snippets para:
  - relación en SnapshotRevisionContractual
  - rutas web
  - botón en snapshots/show

Pasos:
1. Copiar archivos a tu proyecto Laravel respetando rutas.
2. Integrar los snippets indicados.
3. Ejecutar:
   php artisan migrate
   php artisan optimize:clear
