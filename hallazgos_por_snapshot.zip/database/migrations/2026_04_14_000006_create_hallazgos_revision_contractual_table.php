<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('hallazgos_revision_contractual', function (Blueprint $table) {
            $table->id();

            $table->foreignId('snapshot_revision_contractual_id')
                ->constrained('snapshots_revision_contractual')
                ->cascadeOnDelete();

            $table->foreignId('estado_id')
                ->nullable()
                ->constrained('estados');

            $table->string('titulo', 255);
            $table->string('tipo_hallazgo', 50)->nullable();
            $table->string('tipo_riesgo', 100)->nullable();
            $table->string('nivel_criticidad', 50)->nullable();

            $table->longText('hecho_acreditado')->nullable();
            $table->longText('observacion')->nullable();
            $table->longText('fundamento_documental')->nullable();
            $table->longText('consecuencia_posible')->nullable();
            $table->longText('recomendacion')->nullable();

            $table->foreignId('user_id')->constrained('users');

            $table->timestamps();

            $table->index('snapshot_revision_contractual_id', 'idx_hallazgo_snapshot');
            $table->index('estado_id', 'idx_hallazgo_estado');
            $table->index('tipo_hallazgo', 'idx_hallazgo_tipo');
            $table->index('nivel_criticidad', 'idx_hallazgo_criticidad');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('hallazgos_revision_contractual');
    }
};
