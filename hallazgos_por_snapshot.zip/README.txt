Paquete Hallazgos por Snapshot

Incluye:
- Migración de hallazgos_revision_contractual
- Modelo HallazgoRevisionContractual
- Request StoreHallazgoRevisionContractualRequest
- Controller HallazgoRevisionContractualController
- Vistas:
  - contractual/hallazgos/index.blade.php
  - contractual/hallazgos/create.blade.php
  - contractual/hallazgos/show.blade.php
- Snippets para:
  - relación en SnapshotRevisionContractual
  - rutas web
  - botón en snapshots/show

Pasos:
1. Copiar archivos a tu proyecto Laravel respetando rutas.
2. Integrar los snippets indicados.
3. Ejecutar:
   php artisan migrate
   php artisan optimize:clear
