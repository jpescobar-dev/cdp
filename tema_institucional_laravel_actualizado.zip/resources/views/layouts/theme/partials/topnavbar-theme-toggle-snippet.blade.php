{{-- Botón sugerido para layouts.theme.partials.topnavbar --}}
<li class="nav-item d-flex align-items-center ml-3">
    <button type="button"
            class="theme-toggle-btn"
            onclick="toggleInstitutionalTheme()"
            title="Cambiar modo claro/oscuro"
            aria-label="Cambiar modo claro/oscuro">
        <i class="fas fa-adjust mr-1"></i>
        Tema
    </button>
</li>
