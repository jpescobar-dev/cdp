Integración OpenAI para módulo contractual

Incluye:
- Servicio OpenAIRevisionContractualService
- Controller AnalisisRevisionContractualController
- Snippets para:
  - config/services.php
  - .env
  - routes/web.php
  - botón en revisiones/show

Flujo:
1. Toma la revisión y sus documentos.
2. Llama a OpenAI Responses API.
3. Crea un nuevo snapshot.
4. Guarda resumen, hallazgos y checklist automáticamente.

Pasos:
1. Copiar archivos respetando rutas.
2. Agregar snippets donde corresponda.
3. Ejecutar:
   php artisan optimize:clear

Requisitos:
- OPENAI_API_KEY en .env
- tablas de snapshots, hallazgos y checklist ya funcionando
