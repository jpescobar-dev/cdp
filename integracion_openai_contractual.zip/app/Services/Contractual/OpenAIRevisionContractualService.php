<?php

namespace App\Services\Contractual;

use App\Models\RevisionContractual;
use Illuminate\Support\Facades\Http;

class OpenAIRevisionContractualService
{
    public function analizar(RevisionContractual $revision): array
    {
        $revision->load(['documentos']);

        $promptSistema = $this->buildSystemPrompt();
        $inputUsuario = $this->buildUserInput($revision);

        $response = Http::withToken(config('services.openai.key'))
            ->baseUrl(config('services.openai.base_url'))
            ->timeout(120)
            ->post('/responses', [
                'model' => config('services.openai.model'),
                'input' => [
                    [
                        'role' => 'system',
                        'content' => [
                            [
                                'type' => 'text',
                                'text' => $promptSistema,
                            ],
                        ],
                    ],
                    [
                        'role' => 'user',
                        'content' => [
                            [
                                'type' => 'text',
                                'text' => $inputUsuario,
                            ],
                        ],
                    ],
                ],
                'text' => [
                    'format' => [
                        'type' => 'json_schema',
                        'name' => 'revision_contractual_resultado',
                        'schema' => $this->buildJsonSchema(),
                        'strict' => true,
                    ],
                ],
            ]);

        if ($response->failed()) {
            throw new \RuntimeException('Error al consultar OpenAI: ' . $response->body());
        }

        $data = $response->json();
        $jsonText = data_get($data, 'output.0.content.0.text');

        if (!$jsonText) {
            throw new \RuntimeException('La respuesta de OpenAI no devolvió JSON estructurado.');
        }

        $resultado = json_decode($jsonText, true);

        if (!is_array($resultado)) {
            throw new \RuntimeException('No fue posible decodificar el JSON de resultado.');
        }

        return [
            'raw_response' => $data,
            'resultado' => $resultado,
        ];
    }

    protected function buildSystemPrompt(): string
    {
        return <<<TXT
Eres un asistente especializado en revisión preliminar contractual.
Debes analizar la documentación disponible y devolver exclusivamente JSON válido.
No inventes antecedentes.
No confundas ausencia con contradicción documental.
No marques "cumple" si existe inconsistencia documental acreditada.
TXT;
    }

    protected function buildUserInput(RevisionContractual $revision): string
    {
        $documentos = $revision->documentos
            ->map(function ($doc) {
                return "- {$doc->nombre_original} | tipo: {$doc->tipo_documento} | ruta: {$doc->ruta}";
            })
            ->implode("\n");

        return <<<TXT
Revisión ID: {$revision->id}
Título: {$revision->titulo}
Descripción: {$revision->descripcion}

Documentos cargados:
{$documentos}

Devuelve:
- resumen
- hallazgos
- checklist
TXT;
    }

    protected function buildJsonSchema(): array
    {
        return [
            'type' => 'object',
            'properties' => [
                'resumen' => ['type' => 'string'],
                'hallazgos' => [
                    'type' => 'array',
                    'items' => [
                        'type' => 'object',
                        'properties' => [
                            'titulo' => ['type' => 'string'],
                            'tipo_hallazgo' => ['type' => 'string'],
                            'tipo_riesgo' => ['type' => 'string'],
                            'nivel_criticidad' => ['type' => 'string'],
                            'hecho_acreditado' => ['type' => 'string'],
                            'observacion' => ['type' => 'string'],
                            'fundamento_documental' => ['type' => 'string'],
                            'consecuencia_posible' => ['type' => 'string'],
                            'recomendacion' => ['type' => 'string'],
                        ],
                        'required' => [
                            'titulo',
                            'tipo_hallazgo',
                            'tipo_riesgo',
                            'nivel_criticidad',
                            'hecho_acreditado',
                            'observacion',
                            'fundamento_documental',
                            'consecuencia_posible',
                            'recomendacion',
                        ],
                        'additionalProperties' => false,
                    ],
                ],
                'checklist' => [
                    'type' => 'array',
                    'items' => [
                        'type' => 'object',
                        'properties' => [
                            'item' => ['type' => 'string'],
                            'estado_item' => ['type' => 'string'],
                            'observacion' => ['type' => 'string'],
                            'referencia_documental' => ['type' => 'string'],
                            'orden' => ['type' => 'integer'],
                        ],
                        'required' => [
                            'item',
                            'estado_item',
                            'observacion',
                            'referencia_documental',
                            'orden',
                        ],
                        'additionalProperties' => false,
                    ],
                ],
            ],
            'required' => ['resumen', 'hallazgos', 'checklist'],
            'additionalProperties' => false,
        ];
    }
}
