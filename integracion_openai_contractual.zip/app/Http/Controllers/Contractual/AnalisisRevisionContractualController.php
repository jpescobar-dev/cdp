<?php

namespace App\Http\Controllers\Contractual;

use App\Http\Controllers\Controller;
use App\Models\ChecklistRevisionContractual;
use App\Models\HallazgoRevisionContractual;
use App\Models\RevisionContractual;
use App\Models\SnapshotRevisionContractual;
use App\Services\Contractual\OpenAIRevisionContractualService;
use Illuminate\Http\RedirectResponse;

class AnalisisRevisionContractualController extends Controller
{
    public function store(
        RevisionContractual $revision,
        OpenAIRevisionContractualService $service
    ): RedirectResponse {
        $resultado = $service->analizar($revision);

        $ultimaVersion = $revision->snapshots()->max('numero_version') ?? 0;
        $nuevaVersion = $ultimaVersion + 1;

        SnapshotRevisionContractual::where('revision_contractual_id', $revision->id)
            ->update(['es_actual' => false]);

        $snapshot = SnapshotRevisionContractual::create([
            'revision_contractual_id' => $revision->id,
            'numero_version' => $nuevaVersion,
            'tipo_ejecucion' => 'openai',
            'resumen' => $resultado['resultado']['resumen'] ?? null,
            'json_resultado' => $resultado['resultado'],
            'es_actual' => true,
            'user_id' => auth()->id(),
        ]);

        foreach (($resultado['resultado']['hallazgos'] ?? []) as $hallazgo) {
            HallazgoRevisionContractual::create([
                'snapshot_revision_contractual_id' => $snapshot->id,
                'titulo' => $hallazgo['titulo'],
                'tipo_hallazgo' => $hallazgo['tipo_hallazgo'],
                'tipo_riesgo' => $hallazgo['tipo_riesgo'],
                'nivel_criticidad' => $hallazgo['nivel_criticidad'],
                'hecho_acreditado' => $hallazgo['hecho_acreditado'],
                'observacion' => $hallazgo['observacion'],
                'fundamento_documental' => $hallazgo['fundamento_documental'],
                'consecuencia_posible' => $hallazgo['consecuencia_posible'],
                'recomendacion' => $hallazgo['recomendacion'],
                'user_id' => auth()->id(),
            ]);
        }

        foreach (($resultado['resultado']['checklist'] ?? []) as $item) {
            ChecklistRevisionContractual::create([
                'snapshot_revision_contractual_id' => $snapshot->id,
                'item' => $item['item'],
                'estado_item' => $item['estado_item'],
                'observacion' => $item['observacion'],
                'referencia_documental' => $item['referencia_documental'],
                'orden' => $item['orden'] ?? 0,
                'user_id' => auth()->id(),
            ]);
        }

        return redirect()
            ->route('contractual.revisiones.snapshots.show', [$revision, $snapshot])
            ->with('success', 'Análisis generado correctamente.');
    }
}
